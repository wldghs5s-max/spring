package com.kh.app19;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class App19Application {

	public static void main(String[] args) {
		SpringApplication.run(App19Application.class, args);
	}

}
