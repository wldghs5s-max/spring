package com.kh.app19;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class App19ApplicationTests {

	@Test
	void contextLoads() {
	}

}
