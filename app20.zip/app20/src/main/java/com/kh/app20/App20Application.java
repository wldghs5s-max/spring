package com.kh.app20;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class App20Application {

	public static void main(String[] args) {
		SpringApplication.run(App20Application.class, args);
	}

}
