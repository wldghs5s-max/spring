package com.kh.app20;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class App20ApplicationTests {

	@Test
	void contextLoads() {
	}

}
